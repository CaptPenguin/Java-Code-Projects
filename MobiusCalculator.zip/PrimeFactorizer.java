
package mobiuscalculator;
/**
 *
 * @author Troy Zelden
 * 
 * <pre>
 * Date: March 10th, 2021
 * Course: CSC 1350
 * Lab: 6
 * Instructor: Dr. Duncan
 * </pre>
 */
import java.util.*;

public class PrimeFactorizer {

    public static long litOhm(long n)
    {
       int f = 2;
       int currentF = 1;
       int ohm = 0;
       
       while (f <= Math.sqrt(n))
       {
           if (n %f == 0)
           {
               n = n/f;
             if (currentF != f)
             {
                 currentF = f;
                 ohm = ohm + 1;
             }
           }
           else
               f = f + 1;
       }
       if (n > 1 && f != n)
           ohm = ohm + 1;
       return ohm;
    }
    public static long bigOhm(long n)
    { 
        int f = 2;
        int ohm = 0;
        
        while (f <= Math.sqrt(n))
       {
           if (n %f == 0)
           {
               n = n/f;
               ohm = ohm +1;
           }
           else
               f = f + 1;
       }
       if (n > 1)
           ohm = ohm + 1;
       return ohm;

    } 
}