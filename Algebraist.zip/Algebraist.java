
package algebraist;
/**
 *
 * @author Troy Zelden
 * @see PolyUtil
 * <pre>
 * Date: March 24th, 2021
 * Course: CSC 1350
 * Lab: 7
 * Instructor: Dr. Duncan
 * </pre>
 */
import java.util.Scanner;
import java.util.Arrays;
public class Algebraist {

    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);
        System.out.printf("Enter the degree of the polynomial -> ");
        int deg = cin.nextInt();
        if(deg < 0)
            System.out.println("Error: The degree of the polynomial must be nonnegative");
        else{
            double[] coeffs = new double[deg + 1];
            System.out.print("Enter the cooefficients -> ");
            for(int i = 0;i < coeffs.length;i++){
                coeffs[i] = cin.nextInt();
            }
            if(coeffs[0] == 0 && deg != 0)
                System.out.println("Error : Degree > 0 so the coefficient of the highest order term cannot be 0.");
            else
            {
            System.out.println("Enter x at which f(x),f'(x) and f\"(x) will be evaluated -> ");
            double x = cin.nextDouble();
            
            System.out.println();
            System.out.println("f(x) = " + PolyUtil.toString(coeffs));
            System.out.printf("f(%.1f) = %.1f\n",x,PolyUtil.eval(coeffs ,x));
            
            coeffs = PolyUtil.differentiate(coeffs);
            System.out.println();
            System.out.println("f'(x) = " + PolyUtil.toString(coeffs));
            System.out.printf("f'(%.1f) = %.1f\n", x,PolyUtil.eval(coeffs, x));
            
            coeffs = PolyUtil.differentiate(coeffs);
            System.out.println();
            System.out.println("f''(x) = " + PolyUtil.toString(coeffs));
            System.out.printf("f''(%.1f) = %.1f\n", x,PolyUtil.eval(coeffs, x));

            }
        }
    }
}
