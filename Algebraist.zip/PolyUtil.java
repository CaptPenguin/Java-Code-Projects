
package algebraist;
/**
 *
 * @author Troy Zelden
 * <pre>
 * Date: March 24th, 2021
 * Course: CSC 1350
 * Lab:7
 * Instructor: Dr. Duncan
 * </pre>
 */
import java.util.Arrays;
public class PolyUtil {

    public static String toString(double[] coeffs){
        String polyStr = "";
        if (coeffs.length == 1) {
            polyStr = polyStr + " " + coeffs[0];
            return polyStr;
        }
        for (int i = 0; i < coeffs.length - 1; i++){
            if (coeffs[i] != 0){
                if (coeffs[i] > 0 && i > 0){
                    polyStr = polyStr + " + ";
                }
                if (coeffs[i] == -1){
                    polyStr = polyStr + " - ";
                }
                else if (coeffs[i] != 1)
                {
                polyStr = polyStr + coeffs[i]; 
                }   
                polyStr = polyStr + "x";
                if(i < coeffs.length - 2){
                polyStr = polyStr + "^" + (coeffs.length - 1 - i) +" ";
                }   
            }  
        }
        if (coeffs[coeffs.length - 1] > 0)
        polyStr = polyStr + " + ";
        if (coeffs[coeffs.length - 1] != 0)
        polyStr = polyStr + coeffs[coeffs.length - 1] + " ";
        return polyStr;
    }
    
    public static double eval(double[] coeffs, double x){
        double sum = 0;
        double powX = 1;
        
        int deg = coeffs.length-1;
      for (int i = deg; i>= 0; i--)
      {
        sum = sum+ coeffs[i]*powX;
        powX = powX * x;
      }
        return sum;
    }
    
    public static double[] differentiate(double[] coeffs){
        if (coeffs.length <= 1) {
            double[] array = new double[1];
            array[0] = 0;
            return array;
        }
        double[] array = new double[coeffs.length - 1];
        for(int i = 0; i < array.length; i++) {
            int deg = array.length - i;
            array[i] = coeffs[i] * deg;
        }
        return array;
    } 
}