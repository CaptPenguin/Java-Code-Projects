package mobiuscalculator;
import java.util.Scanner; 
/**
 * Understand a Mobius Function
 * @author Troy Zelden
 * @see PrimeFactorizer
 * <pre>
 * Date: March 10th, 2021
 * Course: CSC 1350
 * Lab: 6
 * Instructor: Dr.Duncan
 * </pre>
 */
import java.util.*;
public class MobiusCalculator {
    
 
    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);
        System.out.printf("Enter a positive integer -> ");
        long n = cin.nextLong();
        long litOhm = PrimeFactorizer.litOhm(n);
        long bigOhm = PrimeFactorizer.bigOhm(n);
        int mu;
        if(n < 0)
            System.out.println("Error: You must enter a positive integer.");
        if (litOhm < bigOhm)
            mu = 0;
        else if (litOhm %2 == 0)
            mu = 1;
        else 
            mu = -1;
            System.out.println("little -omega(" + n + ") = " + litOhm);
            System.out.println("big -Omega(" + n + ") = " + bigOhm);
            System.out.println("mu(" + n + ") = " + mu);
       
    }
    
}
