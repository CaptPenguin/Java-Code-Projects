//Troy Zelden
//896677415
//Section: 1
//Submission Time: 6:30
package carsproject;

public class Car { 
    private long VIN;
    private int year;
    private String model;
    private double mileage;
    
    public Car(long carVIN,int carYear,String carModel){ //Constructor
            VIN = carVIN;
            year = carYear;
            model = carModel;
    }
    public void setMileage(double carMileage){
        mileage = carMileage;
    }
    public String getInfo(){  //Getter
        return String.format("%d %s(VIN:%d, mileage:%,.1f mile)",year, model, VIN, mileage);
    }
}
